"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, CheckCircle2, Clock } from "lucide-react"
import Link from "next/link"

interface DocumentCardProps {
  id: string
  title: string
  party1_name: string
  party2_name: string
  party1_signature: string | null
  party2_signature: string | null
  created_at: string
}

export function DocumentCard({
  id,
  title,
  party1_name,
  party2_name,
  party1_signature,
  party2_signature,
  created_at,
}: DocumentCardProps) {
  const createdDate = new Date(created_at).toLocaleDateString("ar-SA", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const bothSigned = party1_signature && party2_signature
  const partiallySigned = (party1_signature && !party2_signature) || (!party1_signature && party2_signature)

  return (
    <Link href={`/document/${id}`}>
      <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
        <CardHeader>
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-start gap-3 flex-1">
              <div className="p-2 bg-primary/10 rounded-lg">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <CardTitle className="text-lg leading-tight" dir="rtl">
                {title}
              </CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between" dir="rtl">
              <span className="text-muted-foreground">الطرف الأول:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium">{party1_name}</span>
                {party1_signature ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                ) : (
                  <Clock className="h-4 w-4 text-amber-500" />
                )}
              </div>
            </div>
            <div className="flex items-center justify-between" dir="rtl">
              <span className="text-muted-foreground">الطرف الثاني:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium">{party2_name}</span>
                {party2_signature ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                ) : (
                  <Clock className="h-4 w-4 text-amber-500" />
                )}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground" dir="rtl">
            {createdDate}
          </span>
          {bothSigned ? (
            <Badge variant="default" className="bg-green-500">
              مكتمل
            </Badge>
          ) : partiallySigned ? (
            <Badge variant="secondary" className="bg-amber-500 text-white">
              قيد التوقيع
            </Badge>
          ) : (
            <Badge variant="outline">بانتظار التوقيع</Badge>
          )}
        </CardFooter>
      </Card>
    </Link>
  )
}
