import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"
import { headers } from "next/headers"

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const { party, signature, fullName } = body

    if (!party || !signature || !fullName) {
      return NextResponse.json({ error: "Party, signature, and full name are required" }, { status: 400 })
    }

    // Get IP address
    const headersList = await headers()
    const ip = headersList.get("x-forwarded-for")?.split(",")[0] || headersList.get("x-real-ip") || "unknown"

    const supabase = await createClient()

    const updateData =
      party === "party1"
        ? {
            party1_signature: signature,
            party1_full_name: fullName,
            party1_signed_at: new Date().toISOString(),
            party1_ip: ip,
          }
        : {
            party2_signature: signature,
            party2_full_name: fullName,
            party2_signed_at: new Date().toISOString(),
            party2_ip: ip,
          }

    const { data, error } = await supabase.from("documents").update(updateData).eq("id", id).select().single()

    if (error) throw error

    return NextResponse.json({ success: true, document: data })
  } catch (error) {
    console.error("[v0] Error saving signature:", error)
    return NextResponse.json({ error: "Failed to save signature" }, { status: 500 })
  }
}
