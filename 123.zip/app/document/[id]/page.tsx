"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SignatureCanvas } from "@/components/signature-canvas"
import { Lock } from "lucide-react"

interface DocumentData {
  id: string
  title: string
  content: string
  party1_name: string
  party2_name: string
  party1_signature: string | null
  party2_signature: string | null
  party1_full_name: string | null
  party2_full_name: string | null
}

export default async function DocumentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  return <DocumentPageContent id={id} />
}

function DocumentPageContent({ id }: { id: string }) {
  const [verificationCode, setVerificationCode] = useState("")
  const [isVerified, setIsVerified] = useState(false)
  const [loading, setLoading] = useState(false)
  const [document, setDocument] = useState<DocumentData | null>(null)
  const [party, setParty] = useState<"party1" | "party2" | null>(null)
  const [partyName, setPartyName] = useState("")
  const [signature, setSignature] = useState<string | null>(null)
  const [error, setError] = useState("")
  const [fullName, setFullName] = useState("")

  useEffect(() => {
    if (isVerified && document) {
      if (party === "party1" && document.party1_signature) {
        setSignature(document.party1_signature)
        if (document.party1_full_name) {
          setFullName(document.party1_full_name)
        }
      } else if (party === "party2" && document.party2_signature) {
        setSignature(document.party2_signature)
        if (document.party2_full_name) {
          setFullName(document.party2_full_name)
        }
      }
    }
  }, [isVerified, document, party])

  const handleVerify = async () => {
    setLoading(true)
    setError("")

    try {
      const response = await fetch(`/api/documents/${id}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: verificationCode }),
      })

      const data = await response.json()

      if (data.valid) {
        setIsVerified(true)
        setDocument(data.document)
        setParty(data.party)
        setPartyName(data.partyName)
      } else {
        setError("رمز التحقق غير صحيح")
      }
    } catch (err) {
      console.error("[v0] Verification error:", err)
      setError("حدث خطأ أثناء التحقق")
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSignature = async (signatureData: string) => {
    if (!fullName.trim()) {
      setError("يرجى إدخال الاسم الكامل")
      return
    }

    setLoading(true)
    setError("")

    try {
      const response = await fetch(`/api/documents/${id}/sign`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ party, signature: signatureData, fullName }),
      })

      if (response.ok) {
        setSignature(signatureData)
        const updatedDoc = await response.json()
        setDocument(updatedDoc.document)
        setError("")
      } else {
        setError("فشل في حفظ التوقيع")
      }
    } catch (err) {
      console.error("[v0] Signature error:", err)
      setError("حدث خطأ أثناء حفظ التوقيع")
    } finally {
      setLoading(false)
    }
  }

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <div className="max-w-md w-full border-2 border-slate-300 rounded-lg p-8 shadow-sm">
          <div className="flex flex-col items-center gap-4 mb-6">
            <div className="p-3 bg-slate-100 rounded-full">
              <Lock className="h-8 w-8 text-slate-700" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">التحقق من الهوية</h1>
          </div>
          <p className="text-center text-slate-600 mb-6" dir="rtl">
            يرجى إدخال رمز التحقق الخاص بك للوصول إلى المستند
          </p>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="code" className="text-slate-900">
                رمز التحقق
              </Label>
              <Input
                id="code"
                type="text"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                placeholder="أدخل رمز التحقق"
                dir="ltr"
                className="text-center text-lg tracking-wider border-slate-300"
              />
            </div>
            {error && <p className="text-sm text-red-600 text-center">{error}</p>}
            <Button
              onClick={handleVerify}
              disabled={loading || !verificationCode}
              className="w-full bg-slate-900 hover:bg-slate-800"
            >
              {loading ? "جاري التحقق..." : "تحقق"}
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-100 py-8 print:bg-white print:py-0">
      <div
        className="mx-auto bg-white shadow-lg print:shadow-none"
        style={{ width: "210mm", minHeight: "297mm", padding: "20mm" }}
      >
        {/* Document Header */}
        <div className="text-center mb-8 border-b-2 border-slate-900 pb-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">{document?.title}</h1>
          <p className="text-sm text-slate-600">تاريخ الإنشاء: {new Date().toLocaleDateString("ar-SA")}</p>
        </div>

        {/* Document Content */}
        <div className="mb-12 text-slate-900 leading-relaxed" dir="rtl">
          <div className="whitespace-pre-wrap text-justify" style={{ fontSize: "12pt", lineHeight: "1.8" }}>
            {document?.content}
          </div>
        </div>

        {/* Signatures Section */}
        <div className="mt-auto pt-12 grid grid-cols-2 gap-6">
          {/* Party 1 Signature - Left Side */}
          <div className="border-2 border-slate-300 rounded-lg p-4">
            <h3 className="text-sm font-bold text-slate-900 mb-3" dir="rtl">
              الطرف الأول: {document?.party1_name}
            </h3>

            {/* Name Field */}
            <div className="space-y-1 mb-3">
              <Label className="text-xs text-slate-700">الاسم الكامل</Label>
              <div className="border-2 border-slate-300 rounded-md h-16 flex items-center justify-center bg-slate-50">
                {party === "party1" ? (
                  document?.party1_full_name ? (
                    <span className="text-slate-900 text-sm font-medium">{document.party1_full_name}</span>
                  ) : (
                    <Input
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="اكتب اسمك الكامل"
                      dir="rtl"
                      className="h-full text-center text-sm border-0 bg-transparent"
                      disabled={loading}
                    />
                  )
                ) : document?.party1_full_name ? (
                  <span className="text-slate-900 text-sm font-medium">{document.party1_full_name}</span>
                ) : (
                  <span className="text-slate-400 text-xs">في انتظار التوقيع</span>
                )}
              </div>
            </div>

            {/* Signature Field */}
            <div className="space-y-1">
              <Label className="text-xs text-slate-700">التوقيع</Label>
              {party === "party1" && !document?.party1_signature ? (
                <SignatureCanvas
                  onSave={handleSaveSignature}
                  onClear={() => setSignature(null)}
                  disabled={loading}
                  compact={true}
                />
              ) : document?.party1_signature ? (
                <div className="border-2 border-slate-300 rounded-md h-20 flex items-center justify-center bg-slate-50 p-2">
                  <img
                    src={document.party1_signature || "/placeholder.svg"}
                    alt="Party 1 signature"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              ) : (
                <div className="border-2 border-slate-300 rounded-md h-20 flex items-center justify-center bg-slate-50">
                  <span className="text-slate-400 text-xs">في انتظار التوقيع</span>
                </div>
              )}
            </div>
            {party === "party1" && error && <p className="text-xs text-red-600 mt-2 text-center">{error}</p>}
          </div>

          {/* Party 2 Signature - Right Side */}
          <div className="border-2 border-slate-300 rounded-lg p-4">
            <h3 className="text-sm font-bold text-slate-900 mb-3" dir="rtl">
              الطرف الثاني: {document?.party2_name}
            </h3>

            {/* Name Field */}
            <div className="space-y-1 mb-3">
              <Label className="text-xs text-slate-700">الاسم الكامل</Label>
              <div className="border-2 border-slate-300 rounded-md h-16 flex items-center justify-center bg-slate-50">
                {party === "party2" ? (
                  document?.party2_full_name ? (
                    <span className="text-slate-900 text-sm font-medium">{document.party2_full_name}</span>
                  ) : (
                    <Input
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="اكتب اسمك الكامل"
                      dir="rtl"
                      className="h-full text-center text-sm border-0 bg-transparent"
                      disabled={loading}
                    />
                  )
                ) : document?.party2_full_name ? (
                  <span className="text-slate-900 text-sm font-medium">{document.party2_full_name}</span>
                ) : (
                  <span className="text-slate-400 text-xs">في انتظار التوقيع</span>
                )}
              </div>
            </div>

            {/* Signature Field */}
            <div className="space-y-1">
              <Label className="text-xs text-slate-700">التوقيع</Label>
              {party === "party2" && !document?.party2_signature ? (
                <SignatureCanvas
                  onSave={handleSaveSignature}
                  onClear={() => setSignature(null)}
                  disabled={loading}
                  compact={true}
                />
              ) : document?.party2_signature ? (
                <div className="border-2 border-slate-300 rounded-md h-20 flex items-center justify-center bg-slate-50 p-2">
                  <img
                    src={document.party2_signature || "/placeholder.svg"}
                    alt="Party 2 signature"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              ) : (
                <div className="border-2 border-slate-300 rounded-md h-20 flex items-center justify-center bg-slate-50">
                  <span className="text-slate-400 text-xs">في انتظار التوقيع</span>
                </div>
              )}
            </div>
            {party === "party2" && error && <p className="text-xs text-red-600 mt-2 text-center">{error}</p>}
          </div>
        </div>

        {/* Print Button */}
        <div className="mt-8 text-center print:hidden">
          <Button onClick={() => window.print()} className="bg-slate-900 hover:bg-slate-800">
            طباعة المستند
          </Button>
        </div>
      </div>
    </div>
  )
}
